package easypower;

class NotificationTeb {
    private String text;
    
    public NotificationTeb(String text){
        this.text = text;
    }
    
    public String gettext(){
        return text;
    }
}
